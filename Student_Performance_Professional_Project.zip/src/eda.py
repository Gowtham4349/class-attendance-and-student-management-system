
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv('../data/student_performance_data.csv')

print(df.describe())
print(df.groupby('Gender')['Exam_Scores'].mean())

sns.heatmap(df.select_dtypes(include='number').corr(), annot=True)
plt.show()
