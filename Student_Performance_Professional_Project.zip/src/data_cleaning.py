
import pandas as pd
df = pd.read_csv('../data/student_performance_data.csv')
df.drop_duplicates(inplace=True)
df.to_csv('../data/cleaned_student_data.csv', index=False)
print('Cleaning complete')
