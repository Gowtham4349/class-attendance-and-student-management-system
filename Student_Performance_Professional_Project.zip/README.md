
# Student Performance Data Analysis

## Objective
Analyze the impact of attendance, study hours, and assignment scores on student exam performance.

## Tools
- Python
- Pandas
- SQL
- Power BI
- Matplotlib
- Seaborn

## KPIs
- Average Exam Score
- Average Attendance
- Top Performers
- Pass Percentage
