
SELECT * FROM students;
SELECT AVG(Exam_Scores) FROM students;
SELECT MAX(Exam_Scores) FROM students;
SELECT MIN(Exam_Scores) FROM students;
SELECT Gender, AVG(Exam_Scores) FROM students GROUP BY Gender;
SELECT * FROM students ORDER BY Exam_Scores DESC LIMIT 10;
SELECT * FROM students WHERE Attendance > 90;
SELECT * FROM students WHERE Study_Hours > 20;
